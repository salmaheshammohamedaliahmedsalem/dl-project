TRY_TASK1_LOCALBEST_SELECT_TASK2_LGE
Task1 method: labelcase; locally selected from existing trained model predictions.
Task1 EF JSON: copied from OVR256/model_b EF package.
Task2: quick LGE OVR2D model package.
Local Task1 macro Dice: 0.897473
